function [output]=template_heartbeat1(input,gr)
%label，0 denotes normal，1 denotes outlier
label_l=length(input(:,1));
label=zeros(label_l,1);
x=[input label];
%计算每一个心拍的最大值
x_max=max(x(:,1:176),[],2);
x_max_median=median(x_max);
index_max=find(x_max>1.5*x_max_median);
if ~isempty(index_max) 
    for i = 1: length(index_max)
        x(index_max(i),177)=1;
    end
end
normal_index=x(:,177)==0;
normal_index1=find(normal_index);
filterrows=x(normal_index,:);
x_mean=mean(filterrows(:,1:176),1);
%计算每个心拍到平均模板的余弦距离
distance=[];
for j = 1:length(filterrows(:,1))
    d=1-(filterrows(j,1:176)*x_mean')/sqrt((sum(power(filterrows(j,1:176),2)))*(sum(power(x_mean,2))));
    d1=[d normal_index1(j)];
    distance=[distance;d1];
end
thr=mean(distance(:,1))+0.5*std(distance(:,1)); %计算阈值
for j = 1:length(filterrows(:,1))
    if distance(j,1)>thr
        x(distance(j,2),177)=1;
    end
end
normal_index=x(:,177)==0;
normal_index1=find(normal_index);
filterrows=x(normal_index,:);
output=mean(filterrows(:,1:176),1);
abnormal_index=x(:,177)==1;
abnormal_index1=find(abnormal_index);
sample=1:176;
if gr==1
    fig = figure('Color', [1, 1, 1]);
    if ~isempty(abnormal_index1)
       for i = 1: length(abnormal_index1)
           plot(sample,x(abnormal_index1(i),1:176),'b');
           hold on
       end
    end 
    hold on
    for i = 1: length(normal_index1)
            plot(sample,x(normal_index1(i),1:176),'r');
            hold on
    end
end
