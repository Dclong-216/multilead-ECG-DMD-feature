function [L_P,L_P_index,segment_variance]=Fisher_optimal_segment(data)
[m,n]=size(data);
segment_variance=zeros(m,m);
for i=1:m-1
    for j=i+1:m
        segment_variance(i,j)=var(data(i:j))*(j-i);
    end
end
%最优二分割
L_P=zeros(m,m-1);
L_P_index=zeros(m,m-1);
for t=3:m
    L=[];
    for t1=2:t
        L=[L segment_variance(1,t1-1)+segment_variance(t1,t)];
    end
    [L_min,index]=min(L);
    L_P(t,2)=L_min;
    L_P_index(t,2)=index+1;
end
%最优n分割
for K=3:m-1
    for t=(K+1):m
        L=[];
        for t1=(K-1):(t-1)
            L=[L L_P(t1,K-1)+segment_variance(t1+1,t)];
        end
        [L_min,index]=min(L);
        L_P(t,K)=L_min;
        L_P_index(t,K)=index+K-1;
    end
end
end





        