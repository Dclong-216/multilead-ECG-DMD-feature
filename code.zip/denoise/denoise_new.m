function [BWRemoveDataFile]=denoise_new(x,gr)
Fs=250; %设置采样率为250%
%陷波滤波器，去除50Hz工频干扰
%Fnotch = 50; % Notch Frequency
%BW = 80; % Bandwidth
%Apass = 1; % Bandwidth Attenuation
%[b, a] = iirnotch (Fnotch/ (Fs/2), BW/ (Fs/2), Apass);
%Hd1 = dfilt.df2 (b, a);
%y1=filter (Hd1, x);
y1=notch(x);
fp=50;fs=60; %通带截止频率50Hz，阻带起始频率60Hz%                   
rp=1;rs=2.5; %通带纹波设置为1dB,阻带衰减设置为2.5dB%                  
wp=fp/(Fs/2);ws=fs/(Fs/2);     
[n,wn]=buttord(wp,ws,rp,rs);  %计算巴特沃斯滤波器的阶数N和3dB截止频率wn%   
[bz,az] = butter(n,wn);%计算巴特沃斯滤波器系统函数分子、分母多项式系数向量B，A%
LPassDataFile=filtfilt(bz,az,y1); %滤波，x1为需要滤波的信号%
%去除基线漂移
%fmaxd=2.5;
%fmaxn=fmaxd/(Fs/2);
%[b,a]=butter(1,fmaxn,"low");
%dd=filtfilt(b,a,LPassDataFile);
%BWRemoveDataFile=LPassDataFile-dd;
dd=medfilt1(LPassDataFile,75);
BWRemoveDataFile=LPassDataFile-dd;
%平滑信号，去除肌电干扰
Dl1=BWRemoveDataFile;
for k=2:length(Dl1)-1
    Dl1(k)=(2*Dl1(k)-Dl1(k-1)-Dl1(k+1))/sqrt(6);
end
NoisSTD = 1.4826*median(abs(Dl1-median(Dl1)));
DenoisingData= NLM_1dDarbon(BWRemoveDataFile,1.5*(NoisSTD),5000,10);%DenosingData为去噪后的信号%

if gr==1
  subplot(4,1,1),plot(x),title("Raw ECG Signal");hold on;
  subplot(4,1,2),plot(y1),title("Raw ECG Signal with power line noise Removed"),hold on;
  subplot(4,1,3),plot(BWRemoveDataFile),title("Raw ECG Signal with high-frequency noise and Baseline wander Removed"),hold on;
  subplot(4,1,4),plot(DenoisingData),title("Raw ECG Signal after smoothing"),hold on;
end
end