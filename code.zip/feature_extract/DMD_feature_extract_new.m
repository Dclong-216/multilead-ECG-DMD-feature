function feature=DMD_feature_extract_new(X,lower_boundry,upper_boundry)

%输入的动态模式分解功率谱和对应频率
%lower_boundry:频率下界;upper_boundry:频率上界
feature=[];
index=X(:,2)>=lower_boundry & X(:,2)<upper_boundry;
X1=X(index,1:2);
total_f_P=X1(:,1).*X1(:,2);
centroid=sum(total_f_P)/sum(X1(:,1)); %导联总体质心频率
MSF=sqrt(sum((X1(:,1).^2).*X1(:,2))/sum(X1(:,1))); %导联总体均方根频率
VF=sqrt(sum(((X1(:,2)-centroid).^2).*X1(:,1))/sum(X1(:,1))); %导联总体频率标准差
skewness=sum(((X1(:,2)-centroid).^3).*X1(:,1))/((VF^3)*sum(X1(:,1))); %导联总体谱偏度
kurtosis=sum(((X1(:,2)-centroid).^4).*X1(:,1))/((VF^4)*sum(X1(:,1))); %导联总体谱峰度
crest=max(X1(:,1))/(sum(X1(:,1))/(max(X1(:,2))-min(X1(:,2)))); %导联总体峰值因子
P_f1=X1(1:length(X1(:,1))-1,:);
k=(length(X1(:,1))-1:-1:1)';
decrease=sum(P_f1(:,1)-X1(end,1)./k)/sum(P_f1(:,1)); % 下降度
P_f2=0;
for m=length(X1(:,1)):-1:1
    P_f2=P_f2+X1(m,1);
    if P_f2>0.95*(sum(X1(:,1)))
        roll_off=X1(m,2);   %计算频谱滚降度
        break
    end
end
feature=[feature centroid MSF VF skewness kurtosis crest  decrease roll_off];
end


